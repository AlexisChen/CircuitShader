﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FillCircuit : MonoBehaviour {
	Renderer renderer;
	Material material;
	// Use this for initialization
	void Start () {
		renderer = GetComponent<Renderer> ();
		material = renderer.material;
//		renderer.material.shader = Shader.Find ("circuit_texture");
	}
	
	// Update is called once per frame
	void Update () {
		float deltaTime = Time.deltaTime;
		float speed = material.GetFloat ("_FillSpeed");
		float acceleration = material.GetFloat ("_FillAcceleration");
		float amount = material.GetFloat ("_FillAmount");

		speed += acceleration * deltaTime;
		amount += speed * deltaTime;

		material.SetFloat ("_FillSpeed", speed);
		material.SetFloat ("_FillAmount",amount);
	}
}
